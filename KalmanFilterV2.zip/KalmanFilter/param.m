dt = 0.01;

% Model Matrix
A = []; % [3x3]
B = []; % [3x1]
C = []; % [1x3]
D = []; % [1x1]
G = []; % [3x1]

% Tuning
R = 1.0;
Q = 1.0;

% Initial
x0 = 0;
P0 = 0;
